package automation.common;

public class TestLogger {

}
