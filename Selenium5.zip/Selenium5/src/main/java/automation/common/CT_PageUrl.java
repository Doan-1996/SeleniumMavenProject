package automation.common;

public class CT_PageUrl {
public static String ALADA_URL = "https://alada.vn/tai-khoan/dang-nhap.html";
public static String SECTORHUB_URL= "https://selectorshub.com/xpath-practice-page/";
public static String SWebAPI_URL = "https://automationfc.github.io/basic-form/index.html";
public static String DEMOQA_URL = "https://demoqa.com/automation-practice-form";
public static String GLOBAL_URL = "https://www.globalsqa.com/demo-site/select-dropdown-menu/";
public static String CODESTAR_URL = "http://test-system.crmstar.vn/";
}
