package automation.constant;

public class CT_pageURL {

}
